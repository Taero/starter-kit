package pl.spring.demo.exception;

public class BookNotNullIdException extends RuntimeException {
}
