package pl.spring.demo.to;

public interface IdAware {

    public Long getId();
}
